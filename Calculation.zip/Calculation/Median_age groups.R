# Age Group 15-24
counts_15_24 <- c(8, 14, 20, 12, 5, 13)
lower_bounds <- c(0.5, 1, 2, 3, 4, 5)
widths       <- c(0.5, 1, 1, 1, 1, 1)

n <- sum(counts_15_24)
cum_freq <- cumsum(counts_15_24)
# Median is at n/2 = 36. This falls in the 2-3h category.
idx <- 3 # 3rd category

median_15_24 <- lower_bounds[idx] + ((n/2 - cum_freq[idx-1]) / counts_15_24[idx]) * widths[idx]
cat("Median for 15-24:", round(median_15_24, 1), "hrs\n")

# Age Group 25-44
counts_25_44 <- c(3, 14, 6, 3, 2, 1)
lower_bounds <- c(0.5, 1, 2, 3, 4, 5)
widths       <- c(0.5, 1, 1, 1, 1, 1)

n <- sum(counts_25_44)
cum_freq <- cumsum(counts_25_44)
# Median is at n/2 = 14.5. This falls in the 1-2h category.
idx <- 2 

median_25_44 <- lower_bounds[idx] + ((n/2 - cum_freq[idx-1]) / counts_25_44[idx]) * widths[idx]
cat("Median for 25-44:", round(median_25_44, 1), "hrs\n")


# Age Group 45-65
counts_45_65 <- c(13, 4, 5, 2, 2, 0)
lower_bounds <- c(0.5, 1, 2, 3, 4, 5)
widths       <- c(0.5, 1, 1, 1, 1, 1)

n <- sum(counts_45_65)
cum_freq <- cumsum(counts_45_65)
# Median is at n/2 = 13. This falls exactly at the end of the 0.5-1h category.
idx <- 1

median_45_65 <- lower_bounds[idx] + ((n/2 - 0) / counts_45_65[idx]) * widths[idx]
cat("Median for 45-65:", round(median_45_65, 1), "hr\n")