female_counts <- c(16, 16, 14, 10, 5, 9)
male_counts   <- c(8, 16, 17, 7, 4, 5)
lower_limits  <- c(0.5, 1, 2, 3, 4, 5)
widths        <- c(0.5, 1, 1, 1, 1, 1)


calc_grouped_median <- function(counts, limits, widths) {
  n <- sum(counts)
  cum_freq <- cumsum(counts)
  median_idx <- which(cum_freq >= n/2)[1]
  
  L <- limits[median_idx]
  F_prev <- if(median_idx == 1) 0 else cum_freq[median_idx - 1]
  f <- counts[median_idx]
  w <- widths[median_idx]
  
  median_val <- L + ((n/2 - F_prev) / f) * w
  return(round(median_val, 1))
}

# 3. Calculate results
f_med <- calc_grouped_median(female_counts, lower_limits, widths)
f_med
m_med <- calc_grouped_median(male_counts, lower_limits, widths)
m_med
