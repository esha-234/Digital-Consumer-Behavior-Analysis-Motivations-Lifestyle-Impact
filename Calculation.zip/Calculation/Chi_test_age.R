# 1. Create the data matrix (excluding the "Total" column)
social_media_data <- matrix(c(
  20, 6, 5,    # 2-3 hours
  12, 3, 2,    # 3-4 hours
  14, 14, 4,   # 1-2 hours
  8, 3, 13,    # 30-60 minutes
  13, 1, 0,    # 5 hours & Over
  5, 2, 2      # 4-5 hours
), nrow = 6, byrow = TRUE)

# 2. Add names for clarity
rownames(social_media_data) <- c("2-3h", "3-4h", "1-2h", "30-60m", "5h+", "4-5h")
colnames(social_media_data) <- c("15-24", "25-44", "45-65")

# 3. View the table
print(social_media_data)

# 4. Perform the Chi-square test
chi_result <- chisq.test(social_media_data)

# 5. Output the results
print(chi_result)

# 6. Check expected frequencies (important for validity)
print(chi_result$expected)