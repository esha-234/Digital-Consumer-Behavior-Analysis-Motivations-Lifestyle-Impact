# 1. Create the data matrix for Gender vs. Social Media Hours
gender_data <- matrix(c(
  14, 17,   # 2-3 hours
  10, 7,    # 3-4 hours
  16, 16,   # 1-2 hours
  16, 8,    # 30-60 minutes
  9, 5,     # 5 hours & Over
  5, 4      # 4-5 hours
), nrow = 6, byrow = TRUE)

# 2. Add names for rows and columns
rownames(gender_data) <- c("2-3h", "3-4h", "1-2h", "30-60m", "5h+", "4-5h")
colnames(gender_data) <- c("Female", "Male")

# 3. View the table to ensure it matches your image
print(gender_data)

# 4. Perform the Chi-square test
gender_test <- chisq.test(gender_data)

# 5. Display the main results
print(gender_test)

# 6. Check expected values (to see if they are below 5)
print(gender_test$expected)